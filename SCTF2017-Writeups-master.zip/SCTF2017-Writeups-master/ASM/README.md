
# Add,Sub,Mul

## Setup
```
python3 run.py
```

## Description

> Addition, Subtraction, Multiplication.

> Toooooooooo e3sy to calculate!

> I believe you can solve 100 problems in 80 seconds:P

> http://ip:port

## comment

Just use any OCR library to get text from the image.

Separating each color would be helpful!
